# Project notes

- Phase 1 is mock-only and must remain usable without Azure or audio devices.
- Keep audio, speech, routing, translation, persistence, WebSocket, export, and UI concerns in their own modules.
- Persist finalized utterances only.
- Never commit secrets, runtime databases, or build artifacts.

