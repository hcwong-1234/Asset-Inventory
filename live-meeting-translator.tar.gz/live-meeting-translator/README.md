# DAIKAI Live Meeting Translator

Local-first bilingual meeting captions for English/Japanese meetings. Phase 1 runs entirely in mock mode: no Azure account, Teams integration, microphone, or paid API is required.

## Run

```bash
cd backend && python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

In another terminal:

```bash
cd frontend && npm install && npm run dev
```

Open the Vite URL. `APP_SPEECH_MODE=mock` emits realistic interim and final bilingual utterances over WebSockets. Azure Speech, translation, and PipeWire capture can be added behind the existing interfaces.

## Phase 2 audio device discovery

The app uses the maintained sounddevice package (PortAudio bindings) for cross-platform device enumeration. It supports Python 3.12, Windows WASAPI host discovery, and Linux PortAudio devices. No audio is captured in this phase.

Windows is the primary production target. WASAPI playback devices are exposed as loopback-capable where possible; Phase 3/4 can use native WASAPI loopback capture without requiring a virtual audio cable.

On Ubuntu/Linux, microphones and playback devices are enumerated through PortAudio. When pactl is available, PipeWire/PulseAudio .monitor sources are exposed as loopback devices. Missing audio libraries, unavailable pactl, and empty device lists are returned as warnings in GET /api/devices.

## Phase 3 microphone capture

Phase 3 captures the selected microphone only. Windows uses the WASAPI-normalized device IDs discovered in Phase 2; Linux uses PortAudio IDs that work with PulseAudio, PipeWire compatibility, or ALSA devices. No system/loopback audio is captured yet.

Capture is normalized to mono, signed 16-bit PCM with 16 kHz preferred. If a device rejects 16 kHz, its supported default sample rate is used and logged so a later dedicated resampler can normalize it before speech recognition. PCM remains in memory for callback analysis only and is discarded; it is never sent to the frontend or written to disk.

The input meter is a throttled 0.0–1.0 RMS/peak level estimate, published at approximately 8 updates per second over the microphone-test WebSocket. The UI visibly shows MICROPHONE ACTIVE while testing.

### Manual microphone test

1. Start the backend and frontend.
2. Select a microphone in the Audio devices panel.
3. Click Test Microphone and speak. Confirm the Input level meter moves and MICROPHONE ACTIVE is visible.
4. Use the microphone test API or browser controls to pause, resume, and stop.
5. Repeat start/stop several times.
6. On Windows, repeat with a USB headset microphone if available.
7. On Ubuntu, test a Pulse/PipeWire microphone and an ALSA microphone if available.

Common errors include a disconnected device, permission denial, an exclusive/busy microphone, or unsupported sample rate. Close applications holding the microphone, confirm OS microphone permissions, and retry device discovery.

Microphone testing is explicit and visible. The application never starts microphone capture silently, and no captured audio is persisted.

## Tests

```bash
cd backend && pytest
```
