from pydantic import BaseModel

class TranslationResult(BaseModel):
    source_text: str
    translated_text: str
    source_language: str
    target_language: str

