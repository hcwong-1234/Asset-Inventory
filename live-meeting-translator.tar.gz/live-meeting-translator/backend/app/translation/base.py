from abc import ABC, abstractmethod
from .models import TranslationResult

class TranslationProvider(ABC):
    @abstractmethod
    async def translate(self, text: str, source_language: str, target_language: str) -> TranslationResult: ...

