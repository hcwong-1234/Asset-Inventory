from .base import TranslationProvider
from .models import TranslationResult

class MockTranslationProvider(TranslationProvider):
    phrases = {
        "来週のテストについて確認したいです。": "I would like to confirm next week's test.",
        "水曜日に実施できますか？": "Can we carry it out on Wednesday?",
        "Yes, we can carry out the test on Wednesday.": "はい、水曜日にテストを実施できます。",
        "Yes, Wednesday is fine.": "はい、水曜日で大丈夫です。",
    }
    async def translate(self, text: str, source_language: str, target_language: str) -> TranslationResult:
        return TranslationResult(source_text=text, translated_text=self.phrases.get(text, f"[Mock {target_language}] {text}"), source_language=source_language, target_language=target_language)

