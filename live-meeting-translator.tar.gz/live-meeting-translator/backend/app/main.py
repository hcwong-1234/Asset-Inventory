from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from app.database.db import init_db, SessionLocal
from app.speech.mock_recognizer import MockSpeechProvider
from app.translation.mock_translator import MockTranslationProvider
from app.websocket.manager import ConnectionManager
from app.meetings.service import MeetingService
from app.meetings.repository import MeetingRepository
from app.api import meetings, exports, devices
from app.api import audio
from app.utils.logging import configure_logging

configure_logging(); init_db()
manager=ConnectionManager()
service=MeetingService(MeetingRepository(SessionLocal()), MockSpeechProvider(), MockTranslationProvider(), manager)
meetings.app_state=type("State", (), {"service": service})()
app=FastAPI(title="DAIKAI Live Meeting Translator")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["*"], allow_headers=["*"])
app.include_router(meetings.router); app.include_router(exports.router); app.include_router(devices.router); app.include_router(audio.router)
@app.get("/health")
def health(): return {"status":"ok", "mode":"mock"}
@app.websocket("/ws/meetings/{meeting_id}")
async def websocket(websocket: WebSocket, meeting_id: str):
    await manager.connect(meeting_id, websocket)
    try:
        while True: await websocket.receive_text()
    except WebSocketDisconnect: manager.disconnect(meeting_id, websocket)

@app.on_event("shutdown")
async def shutdown():
    await audio.manager.shutdown()
