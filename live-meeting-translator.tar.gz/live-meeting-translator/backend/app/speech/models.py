from pydantic import BaseModel
from datetime import datetime

class RecognitionResult(BaseModel):
    text: str
    language: str
    is_final: bool
    timestamp: datetime

