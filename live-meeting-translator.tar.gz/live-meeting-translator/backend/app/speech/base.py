from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from .models import RecognitionResult

class SpeechProvider(ABC):
    @abstractmethod
    async def recognize(self, meeting_id: str) -> AsyncIterator[RecognitionResult]: ...

