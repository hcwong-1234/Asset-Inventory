import asyncio
from datetime import datetime, timezone
from collections.abc import AsyncIterator
from .base import SpeechProvider
from .models import RecognitionResult

class MockSpeechProvider(SpeechProvider):
    script = [
        ("system", "Remote", "ja-JP", "来週のテストについて...", "来週のテストについて確認したいです。"),
        ("microphone", "You", "en-US", "Yes, we can carry out the...", "Yes, we can carry out the test on Wednesday."),
        ("system", "Remote", "ja-JP", "水曜日に実施できますか？", "水曜日に実施できますか？"),
        ("microphone", "You", "en-US", "Yes, Wednesday is...", "Yes, Wednesday is fine."),
    ]
    async def recognize(self, meeting_id: str) -> AsyncIterator[RecognitionResult]:
        for _, _, language, interim, final in self.script:
            now = datetime.now(timezone.utc)
            yield RecognitionResult(text=interim, language=language, is_final=False, timestamp=now)
            await asyncio.sleep(1.0)
            yield RecognitionResult(text=final, language=language, is_final=True, timestamp=datetime.now(timezone.utc))
            await asyncio.sleep(1.5)

