LANGUAGE_TARGETS = {"en-US": "ja-JP", "ja-JP": "en-US"}

def target_language(source_language: str) -> str:
    if source_language not in LANGUAGE_TARGETS:
        raise ValueError(f"Unsupported language: {source_language}")
    return LANGUAGE_TARGETS[source_language]

