from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_speech_mode: str = "mock"
    database_url: str = "sqlite:///./data/daikai.db"
    azure_speech_key: str = ""
    azure_speech_region: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

