from abc import ABC, abstractmethod
from .models import AudioDevice

class AudioSource(ABC):
    source_type: str
    @abstractmethod
    async def start(self) -> None: ...
    @abstractmethod
    async def stop(self) -> None: ...


class AudioDeviceProvider(ABC):
    platform_name: str
    warnings: list[str]

    @abstractmethod
    def list_microphones(self) -> list[AudioDevice]: ...

    @abstractmethod
    def list_playback_devices(self) -> list[AudioDevice]: ...

    @abstractmethod
    def list_loopback_devices(self) -> list[AudioDevice]: ...
