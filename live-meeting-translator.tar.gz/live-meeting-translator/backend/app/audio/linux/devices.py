import json
import shutil
import subprocess
from ..base import AudioDeviceProvider
from ..devices import AudioDeviceDiscoveryError
from ..models import AudioDevice


class LinuxAudioDeviceProvider(AudioDeviceProvider):
    platform_name = "Linux"

    def __init__(self):
        self.warnings: list[str] = []
        self._devices = self._load_devices()

    def _load_devices(self) -> list[dict]:
        try:
            import sounddevice as sd
            devices = list(sd.query_devices())
            hostapis = list(sd.query_hostapis())
            defaults = sd.default.device
        except ImportError as exc:
            raise AudioDeviceDiscoveryError(
                "Audio device discovery requires the sounddevice package"
            ) from exc
        except Exception as exc:
            self.warnings.append(f"Linux audio device query failed: {exc}")
            return []

        default_input = defaults[0] if defaults else None
        default_output = defaults[1] if defaults else None
        normalized = []
        for index, device in enumerate(devices):
            host_api_index = device.get("hostapi")
            host_api = (
                hostapis[host_api_index].get("name")
                if host_api_index is not None and host_api_index < len(hostapis)
                else None
            )
            normalized.append(
                {
                    "index": index,
                    "name": device.get("name", f"Audio device {index}"),
                    "host_api": host_api,
                    "max_input_channels": int(device.get("max_input_channels", 0) or 0),
                    "max_output_channels": int(device.get("max_output_channels", 0) or 0),
                    "default_samplerate": int(device.get("default_samplerate", 0) or 0) or None,
                    "default_input": index == default_input,
                    "default_output": index == default_output,
                }
            )
        return normalized

    def list_microphones(self) -> list[AudioDevice]:
        return [self._model(d, "microphone", d["default_input"]) for d in self._devices if d["max_input_channels"] > 0]

    def list_playback_devices(self) -> list[AudioDevice]:
        return [self._model(d, "playback", d["default_output"]) for d in self._devices if d["max_output_channels"] > 0]

    def list_loopback_devices(self) -> list[AudioDevice]:
        devices = []
        pactl = shutil.which("pactl")
        if pactl:
            try:
                completed = subprocess.run(
                    [pactl, "-f", "json", "list", "sources"],
                    capture_output=True,
                    text=True,
                    timeout=3,
                    check=True,
                )
                for source in json.loads(completed.stdout):
                    name = source.get("name", "")
                    if name.endswith(".monitor"):
                        props = source.get("properties") or {}
                        devices.append(
                            AudioDevice(
                                id=f"pulse-monitor:{name}",
                                name=source.get("description") or name,
                                kind="loopback",
                                platform=self.platform_name,
                                supports_loopback=True,
                                host_api="PipeWire/PulseAudio",
                                sample_rate=(source.get("sample_spec") or {}).get("rate"),
                                channels=(source.get("sample_spec") or {}).get("channels"),
                            )
                        )
            except (OSError, subprocess.SubprocessError, ValueError, TypeError) as exc:
                self.warnings.append(f"Could not enumerate PulseAudio/PipeWire monitors: {exc}")
        else:
            self.warnings.append("pactl is unavailable; monitor sources could not be enumerated")
        return devices

    def _model(self, device: dict, kind: str, is_default: bool) -> AudioDevice:
        return AudioDevice(
            id=f"portaudio:{device['index']}",
            name=device["name"],
            kind=kind,
            platform=self.platform_name,
            is_default=is_default,
            host_api=device["host_api"],
            sample_rate=device["default_samplerate"],
            channels=device["max_input_channels"] if kind == "microphone" else device["max_output_channels"],
        )
