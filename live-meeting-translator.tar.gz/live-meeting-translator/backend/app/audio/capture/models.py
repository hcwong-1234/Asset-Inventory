from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel


class CaptureState(StrEnum):
    IDLE = "idle"
    STARTING = "starting"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    ERROR = "error"


class AudioChunk(BaseModel):
    source: str = "microphone"
    timestamp: datetime
    sample_rate: int
    channels: int
    sample_width: int
    frame_count: int
    pcm_bytes: bytes


class AudioCaptureStats(BaseModel):
    state: CaptureState
    device_id: str | None = None
    sample_rate: int | None = None
    channels: int | None = None
    level: float = 0.0
    frames_captured: int = 0
    error: str | None = None


class MicrophoneTestRequest(BaseModel):
    device_id: str
