from abc import ABC, abstractmethod
from .models import AudioCaptureStats


class MicrophoneCapture(ABC):
    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def pause(self) -> None: ...

    @abstractmethod
    async def resume(self) -> None: ...

    @abstractmethod
    async def stop(self) -> None: ...

    @abstractmethod
    def is_running(self) -> bool: ...

    @abstractmethod
    def stats(self) -> AudioCaptureStats: ...
