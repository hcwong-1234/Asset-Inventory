import asyncio
import logging
from datetime import datetime, timezone
from fastapi import WebSocket
from .factory import create_microphone_capture
from .models import AudioCaptureStats, CaptureState

logger = logging.getLogger(__name__)


class MicrophoneTestManager:
    def __init__(self):
        self.capture = None
        self.connections: list[WebSocket] = []
        self.level_task: asyncio.Task | None = None

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.connections:
            self.connections.remove(websocket)

    async def start(self, device_id: str) -> AudioCaptureStats:
        if self.capture and self.capture.is_running():
            raise RuntimeError("Microphone is already in use")
        self.capture = create_microphone_capture(device_id)
        await self.capture.start()
        self.level_task = asyncio.create_task(self._publish_levels())
        await self._broadcast("audio.microphone.started", {"device_id": device_id})
        return self.capture.stats()

    async def pause(self) -> AudioCaptureStats:
        self._require_capture()
        await self.capture.pause()
        await self._broadcast("audio.microphone.paused", {})
        return self.capture.stats()

    async def resume(self) -> AudioCaptureStats:
        self._require_capture()
        await self.capture.resume()
        await self._broadcast("audio.microphone.resumed", {})
        return self.capture.stats()

    async def stop(self) -> AudioCaptureStats:
        self._require_capture()
        await self.capture.stop()
        if self.level_task:
            self.level_task.cancel()
            self.level_task = None
        stats = self.capture.stats()
        await self._broadcast("audio.microphone.stopped", {})
        return stats

    def status(self) -> AudioCaptureStats:
        return self.capture.stats() if self.capture else AudioCaptureStats(state=CaptureState.IDLE)

    async def shutdown(self):
        if self.capture and self.capture.stats().state != CaptureState.IDLE:
            await self.stop()
        for websocket in list(self.connections):
            await websocket.close()
        self.connections.clear()

    def _require_capture(self):
        if self.capture is None or self.capture.stats().state == CaptureState.IDLE:
            raise RuntimeError("Microphone test is not active")

    async def _publish_levels(self):
        try:
            while self.capture and self.capture.is_running():
                stats = self.capture.stats()
                await self._broadcast("audio.microphone.level", {"level": stats.level, "timestamp": datetime.now(timezone.utc).isoformat()})
                await asyncio.sleep(0.125)
        except asyncio.CancelledError:
            pass

    async def _broadcast(self, event_type: str, payload: dict):
        message = {"type": event_type, **payload}
        for websocket in list(self.connections):
            try:
                await websocket.send_json(message)
            except Exception:
                logger.exception("microphone test websocket send failed")
                self.disconnect(websocket)
