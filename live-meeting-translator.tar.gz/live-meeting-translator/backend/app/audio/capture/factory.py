import platform
from ..devices import AudioDeviceDiscoveryError


def create_microphone_capture(device_id: str):
    if platform.system() == "Windows":
        from ..windows.microphone import WindowsMicrophoneCapture
        return WindowsMicrophoneCapture(device_id)
    if platform.system() == "Linux":
        from ..linux.microphone import LinuxMicrophoneCapture
        return LinuxMicrophoneCapture(device_id)
    raise AudioDeviceDiscoveryError(f"Unsupported operating system for microphone capture: {platform.system()}")
