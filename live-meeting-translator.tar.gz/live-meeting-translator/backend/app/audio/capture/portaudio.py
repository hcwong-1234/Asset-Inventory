import asyncio
import logging
import math
import threading
from array import array
from datetime import datetime, timezone
from .base import MicrophoneCapture
from .models import AudioCaptureStats, AudioChunk, CaptureState

logger = logging.getLogger(__name__)


class PortAudioMicrophoneCapture(MicrophoneCapture):
    target_sample_rate = 16000

    def __init__(self, device_id: str, expected_prefix: str):
        self.device_id = device_id
        self.expected_prefix = expected_prefix
        self._stream = None
        self._state = CaptureState.IDLE
        self._error: str | None = None
        self._level = 0.0
        self._frames = 0
        self._sample_rate: int | None = None
        self._channels = 1
        self._lock = threading.Lock()

    def _device_index(self) -> int:
        prefix, _, index = self.device_id.partition(":")
        if prefix != self.expected_prefix or not index.isdigit():
            raise ValueError("Selected microphone is unavailable")
        return int(index)

    async def start(self) -> None:
        if self._state in (CaptureState.RUNNING, CaptureState.STARTING):
            raise RuntimeError("Microphone is already in use")
        self._state = CaptureState.STARTING
        try:
            import sounddevice as sd
            index = self._device_index()
            info = sd.query_devices(index)
            if int(info.get("max_input_channels", 0) or 0) < 1:
                raise ValueError("Selected device is not an input microphone")
            requested_rate = self.target_sample_rate
            actual_rate = requested_rate
            try:
                sd.check_input_settings(device=index, channels=1, dtype="int16", samplerate=requested_rate)
            except Exception:
                actual_rate = int(info.get("default_samplerate", requested_rate))
                sd.check_input_settings(device=index, channels=1, dtype="int16", samplerate=actual_rate)
                logger.info("microphone sample rate fallback device_id=%s sample_rate=%s", self.device_id, actual_rate)
            self._sample_rate = actual_rate
            self._stream = sd.InputStream(device=index, channels=1, samplerate=actual_rate, dtype="int16", callback=self._callback)
            self._stream.start()
            self._state = CaptureState.RUNNING
            logger.info("microphone capture started device_id=%s sample_rate=%s channels=%s", self.device_id, actual_rate, self._channels)
        except ImportError as exc:
            self._state = CaptureState.ERROR
            self._error = "Audio library unavailable: install sounddevice"
            logger.exception("microphone audio library unavailable")
            raise RuntimeError(self._error) from exc
        except Exception as exc:
            self._state = CaptureState.ERROR
            self._error = self._friendly_error(exc)
            logger.exception("microphone capture start failed device_id=%s", self.device_id)
            await self.stop()
            self._state = CaptureState.ERROR
            self._error = self._friendly_error(exc)
            raise RuntimeError(self._error) from exc

    async def pause(self) -> None:
        if self._state != CaptureState.RUNNING:
            raise RuntimeError("Microphone is not running")
        self._stream.stop()
        self._state = CaptureState.PAUSED
        logger.info("microphone capture paused device_id=%s", self.device_id)

    async def resume(self) -> None:
        if self._state != CaptureState.PAUSED:
            raise RuntimeError("Microphone is not paused")
        self._stream.start()
        self._state = CaptureState.RUNNING
        logger.info("microphone capture resumed device_id=%s", self.device_id)

    async def stop(self) -> None:
        if self._stream is not None:
            self._state = CaptureState.STOPPING
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None
        if self._state != CaptureState.ERROR:
            self._state = CaptureState.IDLE
        logger.info("microphone capture stopped device_id=%s", self.device_id)

    def is_running(self) -> bool:
        return self._state == CaptureState.RUNNING

    def stats(self) -> AudioCaptureStats:
        with self._lock:
            return AudioCaptureStats(state=self._state, device_id=self.device_id, sample_rate=self._sample_rate, channels=self._channels, level=self._level, frames_captured=self._frames, error=self._error)

    def _callback(self, indata, frames, time_info, status) -> None:
        if status:
            logger.warning("microphone callback status device_id=%s status=%s", self.device_id, status)
        try:
            pcm_bytes = indata.tobytes()
            samples = array("h")
            samples.frombytes(pcm_bytes)
            peak = max((abs(sample) for sample in samples), default=0)
            rms = math.sqrt(sum(sample * sample for sample in samples) / len(samples)) if samples else 0.0
            level = min(1.0, max(peak / 32768.0, (rms / 32768.0) * 1.4))
            with self._lock:
                self._level = level
                self._frames += frames
            _ = AudioChunk(timestamp=datetime.now(timezone.utc), sample_rate=self._sample_rate or self.target_sample_rate, channels=1, sample_width=2, frame_count=frames, pcm_bytes=pcm_bytes)
        except Exception as exc:
            logger.exception("microphone callback failed device_id=%s", self.device_id)
            with self._lock:
                self._state = CaptureState.ERROR
                self._error = f"Audio callback error: {exc}"

    @staticmethod
    def _friendly_error(error: Exception) -> str:
        message = str(error).lower()
        if "permission" in message or "access" in message:
            return "Microphone permission denied"
        if "busy" in message or "device unavailable" in message:
            return "Microphone is already in use"
        if "sample" in message:
            return "Selected microphone does not support the required sample rate"
        return f"Unable to open audio device: {error}"
