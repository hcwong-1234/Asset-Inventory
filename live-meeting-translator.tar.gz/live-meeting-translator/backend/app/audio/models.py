from enum import StrEnum
from pydantic import BaseModel

class AudioSourceType(StrEnum):
    MICROPHONE = "microphone"
    SYSTEM = "system"

class AudioChunk(BaseModel):
    source: AudioSourceType
    data: bytes = b""


class AudioDevice(BaseModel):
    id: str
    name: str
    kind: str
    platform: str
    is_default: bool = False
    supports_loopback: bool = False
    host_api: str | None = None
    sample_rate: int | None = None
    channels: int | None = None


class AudioDeviceCatalog(BaseModel):
    platform: str
    microphones: list[AudioDevice] = []
    playback_devices: list[AudioDevice] = []
    loopback_devices: list[AudioDevice] = []
    warnings: list[str] = []
