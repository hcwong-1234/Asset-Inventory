from ..capture.portaudio import PortAudioMicrophoneCapture


class WindowsMicrophoneCapture(PortAudioMicrophoneCapture):
    def __init__(self, device_id: str):
        super().__init__(device_id, "wasapi")
