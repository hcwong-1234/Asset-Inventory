from collections.abc import Iterable
from ..base import AudioDeviceProvider
from ..devices import AudioDeviceDiscoveryError
from ..models import AudioDevice


class WindowsAudioDeviceProvider(AudioDeviceProvider):
    platform_name = "Windows"

    def __init__(self):
        self.warnings: list[str] = []
        self._devices = self._load_devices()

    def _load_devices(self) -> list[dict]:
        try:
            import sounddevice as sd
            devices = list(sd.query_devices())
            hostapis = list(sd.query_hostapis())
            defaults = sd.default.device
        except ImportError as exc:
            raise AudioDeviceDiscoveryError(
                "Audio device discovery requires the sounddevice package"
            ) from exc
        except Exception as exc:
            self.warnings.append(f"Windows audio device query failed: {exc}")
            return []

        default_input = defaults[0] if defaults else None
        default_output = defaults[1] if defaults else None
        normalized = []
        for index, device in enumerate(devices):
            host_api_index = device.get("hostapi")
            host_api = (
                hostapis[host_api_index].get("name")
                if host_api_index is not None and host_api_index < len(hostapis)
                else None
            )
            normalized.append(
                {
                    "index": index,
                    "name": device.get("name", f"Audio device {index}"),
                    "host_api": host_api,
                    "max_input_channels": int(device.get("max_input_channels", 0) or 0),
                    "max_output_channels": int(device.get("max_output_channels", 0) or 0),
                    "default_samplerate": int(device.get("default_samplerate", 0) or 0) or None,
                    "default_input": index == default_input,
                    "default_output": index == default_output,
                }
            )
        return normalized

    def _audio_devices(self) -> Iterable[dict]:
        return self._devices

    def list_microphones(self) -> list[AudioDevice]:
        return [
            self._model(device, "microphone", device["default_input"])
            for device in self._audio_devices()
            if device["max_input_channels"] > 0
        ]

    def list_playback_devices(self) -> list[AudioDevice]:
        return [
            self._model(device, "playback", device["default_output"])
            for device in self._audio_devices()
            if device["max_output_channels"] > 0
        ]

    def list_loopback_devices(self) -> list[AudioDevice]:
        return [
            self._model(device, "loopback", device["default_output"])
            for device in self._audio_devices()
            if device["max_output_channels"] > 0
            and device["host_api"]
            and "WASAPI" in device["host_api"].upper()
        ]

    def _model(self, device: dict, kind: str, is_default: bool) -> AudioDevice:
        return AudioDevice(
            id=f"wasapi:{device['index']}",
            name=device["name"],
            kind=kind,
            platform=self.platform_name,
            is_default=is_default,
            supports_loopback=kind == "loopback",
            host_api=device["host_api"],
            sample_rate=device["default_samplerate"],
            channels=device["max_input_channels"] if kind == "microphone" else device["max_output_channels"],
        )
