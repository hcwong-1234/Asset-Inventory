from .base import AudioDeviceProvider
from .models import AudioDevice


class AudioDeviceDiscoveryError(RuntimeError):
    """Raised when the platform audio discovery backend cannot be used."""


def safe_list(provider: AudioDeviceProvider) -> dict[str, list[AudioDevice] | list[str]]:
    return {
        "microphones": provider.list_microphones(),
        "playback_devices": provider.list_playback_devices(),
        "loopback_devices": provider.list_loopback_devices(),
        "warnings": provider.warnings,
    }
