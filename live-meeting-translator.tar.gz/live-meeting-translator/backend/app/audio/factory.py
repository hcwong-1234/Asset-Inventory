import platform
from .base import AudioDeviceProvider
from .devices import AudioDeviceDiscoveryError


def get_audio_device_provider() -> AudioDeviceProvider:
    operating_system = platform.system()
    if operating_system == "Windows":
        from .windows.devices import WindowsAudioDeviceProvider
        return WindowsAudioDeviceProvider()
    if operating_system == "Linux":
        from .linux.devices import LinuxAudioDeviceProvider
        return LinuxAudioDeviceProvider()
    raise AudioDeviceDiscoveryError(
        f"Unsupported operating system for audio discovery: {operating_system}"
    )
