from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.database.models import MeetingRecord, UtteranceRecord

class MeetingRepository:
    def __init__(self, db: Session): self.db = db
    def create(self, title: str):
        item = MeetingRecord(title=title); self.db.add(item); self.db.commit(); self.db.refresh(item); return item
    def get(self, meeting_id): return self.db.get(MeetingRecord, meeting_id)
    def list(self): return self.db.query(MeetingRecord).order_by(MeetingRecord.created_at.desc()).all()
    def update_status(self, item, status):
        item.status = status
        if status == "live": item.started_at = datetime.now(timezone.utc)
        if status == "stopped": item.ended_at = datetime.now(timezone.utc)
        self.db.commit(); self.db.refresh(item); return item
    def update_status_by_id(self, meeting_id: str, status: str):
        item = self.get(meeting_id)
        if item is None:
            return None
        return self.update_status(item, status)
    def add_utterance(self, **data):
        item = UtteranceRecord(**data); self.db.add(item); self.db.commit(); self.db.refresh(item); return item
