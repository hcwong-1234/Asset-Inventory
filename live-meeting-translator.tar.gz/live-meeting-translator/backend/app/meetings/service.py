import asyncio
from app.speech.language_router import target_language
from app.translation.base import TranslationProvider
from app.speech.base import SpeechProvider
from app.websocket.events import Event
from app.websocket.manager import ConnectionManager
from .repository import MeetingRepository

class MeetingService:
    def __init__(self, repo: MeetingRepository, speech: SpeechProvider, translator: TranslationProvider, manager: ConnectionManager):
        self.repo, self.speech, self.translator, self.manager = repo, speech, translator, manager
        self.tasks: dict[str, asyncio.Task] = {}
    async def start(self, meeting_id: str):
        meeting = self.repo.update_status_by_id(meeting_id, "live")
        if meeting is None:
            return None
        await self.manager.broadcast(meeting_id, Event(type="meeting.started", meeting_id=meeting_id))
        self.tasks[meeting_id] = asyncio.create_task(self._stream(meeting_id))
        return meeting_id
    async def pause(self, meeting_id: str):
        meeting = self.repo.update_status_by_id(meeting_id, "paused")
        if meeting is None:
            return None
        await self.manager.broadcast(meeting_id, Event(type="meeting.paused", meeting_id=meeting_id))
        return meeting_id
    async def resume(self, meeting_id: str):
        meeting = self.repo.update_status_by_id(meeting_id, "live")
        if meeting is None:
            return None
        await self.manager.broadcast(meeting_id, Event(type="meeting.resumed", meeting_id=meeting_id))
        return meeting_id
    async def stop(self, meeting_id: str):
        if task := self.tasks.pop(meeting_id, None): task.cancel()
        meeting = self.repo.update_status_by_id(meeting_id, "stopped")
        if meeting is None:
            return None
        await self.manager.broadcast(meeting_id, Event(type="meeting.stopped", meeting_id=meeting_id))
        return meeting_id
    async def _stream(self, meeting_id):
        try:
            async for result in self.speech.recognize(meeting_id):
                current = self.repo.get(meeting_id)
                if not current or current.status != "live": continue
                source = "system" if any('\u3040' <= c <= '\u30ff' for c in result.text) else "microphone"
                speaker = "Remote" if source == "system" else "You"
                payload = {"timestamp": result.timestamp.isoformat(), "audio_source": source, "speaker_label": speaker, "detected_language": result.language, "original_text": result.text, "is_final": result.is_final}
                if not result.is_final:
                    await self.manager.broadcast(meeting_id, Event(type="speech.interim", meeting_id=meeting_id, payload=payload))
                    continue
                translated = await self.translator.translate(result.text, result.language, target_language(result.language))
                payload.update({"translated_language": translated.target_language, "translated_text": translated.translated_text})
                item = self.repo.add_utterance(meeting_id=meeting_id, timestamp=result.timestamp, **{k: payload[k] for k in ("audio_source", "speaker_label", "detected_language", "original_text", "translated_language", "translated_text")}, is_final=True)
                payload["id"] = item.id
                await self.manager.broadcast(meeting_id, Event(type="speech.final", meeting_id=meeting_id, payload=payload))
        except asyncio.CancelledError: pass
