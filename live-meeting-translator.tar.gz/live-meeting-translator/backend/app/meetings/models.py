from datetime import datetime
from pydantic import BaseModel, ConfigDict

class MeetingCreate(BaseModel): title: str = "Untitled meeting"
class MeetingView(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str; title: str; status: str; started_at: datetime | None = None; ended_at: datetime | None = None
class UtteranceView(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str; meeting_id: str; timestamp: datetime; audio_source: str; speaker_label: str; detected_language: str; original_text: str; translated_language: str; translated_text: str; is_final: bool

