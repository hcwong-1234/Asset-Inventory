from fastapi.encoders import jsonable_encoder


def export_json(meeting, utterances):
    meeting_data = {
        "id": getattr(meeting, "id", None),
        "title": getattr(meeting, "title", None),
        "started_at": getattr(meeting, "started_at", None),
        "ended_at": getattr(meeting, "ended_at", None),
        "status": getattr(meeting, "status", None),
        "source_languages": getattr(meeting, "source_languages", None),
        "created_at": getattr(meeting, "created_at", None),
    }

    utterance_data = []

    for utterance in utterances:
        utterance_data.append(
            {
                "id": getattr(utterance, "id", None),
                "meeting_id": getattr(utterance, "meeting_id", None),
                "timestamp": getattr(utterance, "timestamp", None),
                "audio_source": getattr(utterance, "audio_source", None),
                "speaker_label": getattr(utterance, "speaker_label", None),
                "detected_language": getattr(
                    utterance, "detected_language", None
                ),
                "original_text": getattr(
                    utterance, "original_text", None
                ),
                "translated_language": getattr(
                    utterance, "translated_language", None
                ),
                "translated_text": getattr(
                    utterance, "translated_text", None
                ),
                "is_final": getattr(utterance, "is_final", None),
                "created_at": getattr(utterance, "created_at", None),
            }
        )

    return jsonable_encoder(
        {
            "meeting": meeting_data,
            "utterances": utterance_data,
        }
    )
