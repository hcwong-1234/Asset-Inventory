def export_txt(meeting, utterances) -> str:
    lines = [f"{meeting.title}\n", "DAIKAI Live Meeting Translator\n"]
    for u in utterances: lines.append(f"{u.timestamp:%H:%M:%S}  {u.speaker_label.upper()}  {u.detected_language}\n{u.original_text}\n{u.translated_language}\n{u.translated_text}\n")
    return "\n".join(lines)

