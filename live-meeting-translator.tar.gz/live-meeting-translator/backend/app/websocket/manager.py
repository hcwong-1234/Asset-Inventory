from fastapi import WebSocket
class ConnectionManager:
    def __init__(self): self.connections: dict[str, list[WebSocket]] = {}
    async def connect(self, meeting_id, websocket):
        await websocket.accept(); self.connections.setdefault(meeting_id, []).append(websocket)
    def disconnect(self, meeting_id, websocket):
        if websocket in self.connections.get(meeting_id, []): self.connections[meeting_id].remove(websocket)
    async def broadcast(self, meeting_id, event):
        for ws in self.connections.get(meeting_id, []): await ws.send_json(event.model_dump(mode="json"))

