from typing import Literal
from pydantic import BaseModel

EventType = Literal["meeting.started", "meeting.paused", "meeting.resumed", "meeting.stopped", "speech.interim", "speech.final", "translation.completed", "error"]
class Event(BaseModel): type: EventType; meeting_id: str; payload: dict = {}

