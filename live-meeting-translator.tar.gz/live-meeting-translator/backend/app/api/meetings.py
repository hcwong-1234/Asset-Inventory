from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.db import SessionLocal
from app.database.models import UtteranceRecord
from app.meetings.models import MeetingCreate, MeetingView, UtteranceView
from app.meetings.repository import MeetingRepository

router = APIRouter(prefix="/api/meetings", tags=["meetings"])
def db():
    session = SessionLocal()
    try: yield session
    finally: session.close()
def get_meeting(repo, meeting_id):
    meeting = repo.get(meeting_id)
    if not meeting: raise HTTPException(404, "Meeting not found")
    return meeting
@router.post("", response_model=MeetingView)
def create(body: MeetingCreate, session: Session = Depends(db)): return MeetingRepository(session).create(body.title)
@router.get("", response_model=list[MeetingView])
def history(session: Session = Depends(db)): return MeetingRepository(session).list()
@router.get("/{meeting_id}", response_model=MeetingView)
def get(meeting_id: str, session: Session = Depends(db)): return get_meeting(MeetingRepository(session), meeting_id)
@router.get("/{meeting_id}/utterances", response_model=list[UtteranceView])
def utterances(meeting_id: str, session: Session = Depends(db)):
    repo = MeetingRepository(session); get_meeting(repo, meeting_id)
    return session.query(UtteranceRecord).filter_by(meeting_id=meeting_id).order_by(UtteranceRecord.timestamp).all()

app_state = None
async def _action(name, meeting_id, session):
    repo = MeetingRepository(session); meeting = get_meeting(repo, meeting_id)
    result = await getattr(app_state.service, name)(meeting_id)
    if result is None:
        raise HTTPException(404, "Meeting not found")
    return get_meeting(repo, meeting_id)
@router.post("/{meeting_id}/start", response_model=MeetingView)
async def start(meeting_id: str, session: Session = Depends(db)): return await _action("start", meeting_id, session)
@router.post("/{meeting_id}/pause", response_model=MeetingView)
async def pause(meeting_id: str, session: Session = Depends(db)): return await _action("pause", meeting_id, session)
@router.post("/{meeting_id}/resume", response_model=MeetingView)
async def resume(meeting_id: str, session: Session = Depends(db)): return await _action("resume", meeting_id, session)
@router.post("/{meeting_id}/stop", response_model=MeetingView)
async def stop(meeting_id: str, session: Session = Depends(db)): return await _action("stop", meeting_id, session)
