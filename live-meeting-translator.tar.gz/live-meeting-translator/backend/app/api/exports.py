from fastapi import APIRouter, Depends, Response, HTTPException
from sqlalchemy.orm import Session
from app.database.db import SessionLocal
from app.database.models import UtteranceRecord
from app.meetings.repository import MeetingRepository
from app.export.txt_exporter import export_txt
from app.export.json_exporter import export_json
router = APIRouter(prefix="/api/meetings", tags=["exports"])
def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
@router.get("/{meeting_id}/export/{format}")
def export(meeting_id: str, format: str, session: Session = Depends(db)):
    repo=MeetingRepository(session); meeting=repo.get(meeting_id)
    if not meeting: raise HTTPException(404, "Meeting not found")
    rows=session.query(UtteranceRecord).filter_by(meeting_id=meeting_id).order_by(UtteranceRecord.timestamp).all()
    if format == "txt": return Response(export_txt(meeting, rows), media_type="text/plain", headers={"Content-Disposition": f'attachment; filename="{meeting.title}.txt"'})
    if format == "json": return export_json(meeting, rows)
    raise HTTPException(400, "Supported formats: txt, json")

