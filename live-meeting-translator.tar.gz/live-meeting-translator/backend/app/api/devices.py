from fastapi import APIRouter
import platform
from app.audio.devices import AudioDeviceDiscoveryError, safe_list
from app.audio.factory import get_audio_device_provider

router = APIRouter(prefix="/api/devices", tags=["devices"])


@router.get("")
def devices():
    try:
        provider = get_audio_device_provider()
        result = {"platform": provider.platform_name, **safe_list(provider)}
        if not result["microphones"]:
            result["warnings"].append("No microphones found")
        if not result["playback_devices"]:
            result["warnings"].append("No playback devices found")
        if not result["loopback_devices"]:
            result["warnings"].append("No loopback/monitor devices found")
        return result
    except AudioDeviceDiscoveryError as exc:
        return {"platform": platform.system(), "microphones": [], "playback_devices": [], "loopback_devices": [], "warnings": [str(exc)]}
