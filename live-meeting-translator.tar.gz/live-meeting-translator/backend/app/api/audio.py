import logging
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from app.audio.capture.manager import MicrophoneTestManager
from app.audio.capture.models import MicrophoneTestRequest

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/audio/microphone/test", tags=["audio"])
manager = MicrophoneTestManager()


def _error(error: Exception):
    logger.exception("microphone test operation failed")
    raise HTTPException(status_code=400, detail=str(error))


@router.post("/start")
async def start(request: MicrophoneTestRequest):
    try:
        stats = await manager.start(request.device_id)
        return stats.model_dump(mode="json")
    except Exception as exc:
        return _error(exc)


@router.post("/pause")
async def pause():
    try:
        return (await manager.pause()).model_dump(mode="json")
    except Exception as exc:
        return _error(exc)


@router.post("/resume")
async def resume():
    try:
        return (await manager.resume()).model_dump(mode="json")
    except Exception as exc:
        return _error(exc)


@router.post("/stop")
async def stop():
    try:
        return (await manager.stop()).model_dump(mode="json")
    except Exception as exc:
        return _error(exc)


@router.get("/status")
def status():
    return manager.status().model_dump(mode="json")


@router.websocket("/ws")
async def websocket(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
