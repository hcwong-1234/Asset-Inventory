import uuid
from datetime import datetime, timezone
from sqlalchemy import String, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

class MeetingRecord(Base):
    __tablename__ = "meetings"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title: Mapped[str] = mapped_column(String(200))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="created")
    source_languages: Mapped[str] = mapped_column(String(100), default="en-US,ja-JP")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    utterances: Mapped[list["UtteranceRecord"]] = relationship(back_populates="meeting", cascade="all, delete-orphan")

class UtteranceRecord(Base):
    __tablename__ = "utterances"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    meeting_id: Mapped[str] = mapped_column(ForeignKey("meetings.id"))
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    audio_source: Mapped[str] = mapped_column(String(20))
    speaker_label: Mapped[str] = mapped_column(String(50))
    detected_language: Mapped[str] = mapped_column(String(10))
    original_text: Mapped[str] = mapped_column(Text)
    translated_language: Mapped[str] = mapped_column(String(10))
    translated_text: Mapped[str] = mapped_column(Text)
    is_final: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    meeting: Mapped[MeetingRecord] = relationship(back_populates="utterances")

