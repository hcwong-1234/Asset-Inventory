import asyncio
from datetime import datetime, timezone
from app.speech.language_router import target_language
from app.speech.mock_recognizer import MockSpeechProvider
from app.translation.mock_translator import MockTranslationProvider
from app.websocket.events import Event
from app.export.txt_exporter import export_txt
from app.export.json_exporter import export_json

def test_language_routing():
    assert target_language("en-US")=="ja-JP"; assert target_language("ja-JP")=="en-US"
def test_event_model():
    event=Event(type="speech.final",meeting_id="abc",payload={"original_text":"hi"}); assert event.type=="speech.final"
def test_mock_recognizer_has_interim_and_final():
    results=asyncio.run(_results()); assert results[0].is_final is False; assert results[1].is_final is True
async def _results():
    out=[]
    async for x in MockSpeechProvider().recognize("x"):
        out.append(x)
        if len(out) == 2: break
    return out
def test_translation():
    result=asyncio.run(MockTranslationProvider().translate("Yes, Wednesday is fine.","en-US","ja-JP")); assert "水曜日" in result.translated_text
def test_exports():
    meeting=type("M",(),{"title":"Demo"})(); row=type("U",(),{"timestamp":datetime.now(timezone.utc),"speaker_label":"You","detected_language":"en-US","original_text":"Hello","translated_language":"ja-JP","translated_text":"こんにちは"})()
    assert "Hello" in export_txt(meeting,[row]); assert export_json(meeting,[row])["meeting"]["title"]=="Demo"
