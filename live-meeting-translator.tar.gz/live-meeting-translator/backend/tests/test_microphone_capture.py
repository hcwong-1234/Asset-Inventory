import asyncio
from datetime import datetime, timezone
from app.audio.capture.manager import MicrophoneTestManager
from app.audio.capture.models import AudioCaptureStats, CaptureState
from app.audio.capture.portaudio import PortAudioMicrophoneCapture


class FakeCapture:
    def __init__(self, device_id):
        self.device_id = device_id
        self.state = CaptureState.IDLE
        self.level = 0.0

    async def start(self):
        if self.state in (CaptureState.RUNNING, CaptureState.STARTING):
            raise RuntimeError("Microphone is already in use")
        self.state = CaptureState.RUNNING

    async def pause(self):
        if self.state != CaptureState.RUNNING:
            raise RuntimeError("Microphone is not running")
        self.state = CaptureState.PAUSED

    async def resume(self):
        if self.state != CaptureState.PAUSED:
            raise RuntimeError("Microphone is not paused")
        self.state = CaptureState.RUNNING

    async def stop(self):
        self.state = CaptureState.IDLE

    def is_running(self):
        return self.state == CaptureState.RUNNING

    def stats(self):
        return AudioCaptureStats(state=self.state, device_id=self.device_id, level=self.level)


def test_capture_state_machine(monkeypatch):
    monkeypatch.setattr("app.audio.capture.manager.create_microphone_capture", FakeCapture)
    async def exercise():
        manager = MicrophoneTestManager()
        await manager.start("portaudio:4")
        assert manager.status().state == CaptureState.RUNNING
        await manager.pause()
        assert manager.status().state == CaptureState.PAUSED
        await manager.resume()
        assert manager.status().state == CaptureState.RUNNING
        await manager.stop()
        assert manager.status().state == CaptureState.IDLE
    asyncio.run(exercise())


def test_invalid_device_id():
    capture = PortAudioMicrophoneCapture("wrong:4", "portaudio")
    try:
        capture._device_index()
    except ValueError as error:
        assert "unavailable" in str(error)
    else:
        raise AssertionError("invalid device should fail")


def test_level_is_normalized():
    class Samples:
        def tobytes(self):
            return b"\xff\x7f" * 100
    capture = PortAudioMicrophoneCapture("portaudio:1", "portaudio")
    capture._callback(Samples(), 100, None, None)
    assert 0.0 <= capture.stats().level <= 1.0
