import platform
from app.audio.factory import get_audio_device_provider
from app.audio.models import AudioDevice
from app.audio.windows.devices import WindowsAudioDeviceProvider
from app.audio.linux.devices import LinuxAudioDeviceProvider


def test_audio_device_model_is_normalized():
    device = AudioDevice(id="x", name="Mic", kind="microphone", platform="Windows")
    assert device.id == "x"
    assert device.supports_loopback is False


def test_windows_provider_selection(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    monkeypatch.setattr(WindowsAudioDeviceProvider, "_load_devices", lambda self: [])
    assert isinstance(get_audio_device_provider(), WindowsAudioDeviceProvider)


def test_linux_provider_selection(monkeypatch):
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    monkeypatch.setattr(LinuxAudioDeviceProvider, "_load_devices", lambda self: [])
    assert isinstance(get_audio_device_provider(), LinuxAudioDeviceProvider)


def test_empty_device_lists_are_safe():
    provider = object.__new__(WindowsAudioDeviceProvider)
    provider.warnings = []
    provider._devices = []
    assert provider.list_microphones() == []
    assert provider.list_playback_devices() == []
    assert provider.list_loopback_devices() == []
