import { useEffect, useRef, useState } from 'react';
import { Languages, History, Settings2, Activity } from 'lucide-react';
import { createMeeting, meetingAction, listDevices, microphoneTestAction, microphoneTestWsUrl, wsUrl, exportUrl } from './api/client';
import { Status, Utterance, DeviceCatalog, CaptureStatus } from './types';
import MeetingControls from './components/MeetingControls';
import TranscriptFeed from './components/TranscriptFeed';
import StatusBar from './components/StatusBar';

export default function App() {
  const [meeting, setMeeting] = useState<any>();
  const [status, setStatus] = useState<Status>('created');
  const [items, setItems] = useState<Utterance[]>([]);
  const [seconds, setSeconds] = useState(0);
  const [devices, setDevices] = useState<DeviceCatalog>();
  const [deviceError, setDeviceError] = useState('');
  const [microphoneId, setMicrophoneId] = useState('');
  const [meetingAudioId, setMeetingAudioId] = useState('');
  const [capture, setCapture] = useState<CaptureStatus>({ state: 'idle', level: 0, frames_captured: 0 });
  const socket = useRef<WebSocket | null>(null);
  const microphoneSocket = useRef<WebSocket | null>(null);

  useEffect(() => {
    listDevices().then((catalog: DeviceCatalog) => {
      setDevices(catalog);
      setMicrophoneId(catalog.microphones.find(device => device.is_default)?.id || '');
      setMeetingAudioId(catalog.loopback_devices[0]?.id || catalog.playback_devices.find(device => device.is_default)?.id || '');
    }).catch(error => { console.error('[DAIKAI] device discovery failed', error); setDeviceError('Audio devices could not be loaded. You can still use mock mode.'); });
  }, []);
  useEffect(() => { if (status !== 'live') return; const timer = setInterval(() => setSeconds(value => value + 1), 1000); return () => clearInterval(timer); }, [status]);

  function connectMeetingSocket(id: string) {
    return new Promise<void>((resolve, reject) => {
      const connection = new WebSocket(wsUrl(id)); socket.current = connection;
      connection.onopen = () => { console.info('[DAIKAI] WebSocket connected', wsUrl(id)); resolve(); };
      connection.onerror = event => { console.error('[DAIKAI] WebSocket connection failed', event); reject(new Error('Unable to connect to the meeting WebSocket')); };
      connection.onclose = event => console.info('[DAIKAI] WebSocket closed', event.code, event.reason);
      connection.onmessage = event => { try { const message = JSON.parse(event.data); console.debug('[DAIKAI] event received', message.type); if (message.type === 'speech.interim' || message.type === 'speech.final') setItems(old => [...old.filter(item => item.is_final), message.payload]); } catch (error) { console.error('[DAIKAI] Invalid WebSocket event', error, event.data); } };
    });
  }

  async function action(actionName: string) {
    try {
      let current = meeting;
      if (!current || (actionName === 'start' && status === 'stopped')) { current = await createMeeting('Bilingual sync · ' + new Date().toLocaleDateString()); setMeeting(current); setItems([]); setSeconds(0); socket.current = null; }
      if (actionName === 'start' && !socket.current) await connectMeetingSocket(current.id);
      const result = await meetingAction(current.id, actionName); console.info('[DAIKAI] meeting action completed', actionName, result); setMeeting(result);
      if (actionName === 'start') setStatus('live'); if (actionName === 'pause') setStatus('paused'); if (actionName === 'resume') setStatus('live');
      if (actionName === 'stop') { setStatus('stopped'); socket.current?.close(); socket.current = null; }
    } catch (error) { console.error('[DAIKAI] meeting action failed', actionName, error); }
  }

  async function testMicrophone(actionName: string) {
    try {
      if (actionName === 'start') {
        if (!microphoneId) throw new Error('Select a microphone first');
        if (!microphoneSocket.current) {
          const connection = new WebSocket(microphoneTestWsUrl()); microphoneSocket.current = connection;
          connection.onmessage = event => { const message = JSON.parse(event.data); if (message.type === 'audio.microphone.level') setCapture(old => ({ ...old, state: 'running', level: message.level })); };
          connection.onerror = event => console.error('[DAIKAI] microphone WebSocket failed', event);
          await new Promise<void>((resolve, reject) => { connection.onopen = () => resolve(); connection.onerror = () => reject(new Error('Unable to connect to microphone test WebSocket')); });
        }
      }
      const result = await microphoneTestAction(actionName, microphoneId); setCapture(result); console.info('[DAIKAI] microphone test action completed', actionName, result);
    } catch (error) { console.error('[DAIKAI] microphone test failed', actionName, error); setCapture(old => ({ ...old, state: 'error', error: error instanceof Error ? error.message : 'Unable to test microphone' })); }
  }
  function stopMicrophoneTest() { testMicrophone('stop').finally(() => { microphoneSocket.current?.close(); microphoneSocket.current = null; }); }
  function exportFile(format: string) { if (meeting) window.open(exportUrl(meeting.id, format), '_blank'); }

  return <main><header><div className="brand"><div className="brandmark"><Languages size={19} /></div><div><h1>DAIKAI</h1><small>LIVE MEETING TRANSLATOR</small></div></div><nav><button><History size={16} /> Meeting history</button><button><Settings2 size={16} /> Settings</button><div className="avatar">DK</div></nav></header><div className="workspace"><div className="eyebrow"><Activity size={15} /> LIVE WORKSPACE</div><div className="title-line"><div><h2>Live meeting</h2><p>{meeting?.title || 'Create a meeting session to begin translating'}</p></div><StatusBar status={status} seconds={seconds} /></div><div className="device-panel"><div className="device-heading"><span>Audio devices</span><span>{devices?.platform || 'Detecting OS'} · selection only</span></div><div className="device-grid"><label>Microphone<select value={microphoneId} onChange={event => setMicrophoneId(event.target.value)}><option value="">Select microphone</option>{devices?.microphones.map(device => <option key={device.id} value={device.id}>{device.name}{device.is_default ? ' · Default' : ''}</option>)}</select></label><label>Meeting audio<select value={meetingAudioId} onChange={event => setMeetingAudioId(event.target.value)}><option value="">Select output / loopback</option>{devices?.loopback_devices.map(device => <option key={device.id} value={device.id}>{device.name} · Loopback</option>)}{devices?.playback_devices.filter(device => !devices.loopback_devices.some(loopback => loopback.name === device.name)).map(device => <option key={device.id} value={device.id}>{device.name}</option>)}</select></label></div>{deviceError && <p className="device-warning">{deviceError}</p>}{devices?.warnings.map((warning, index) => <p className="device-warning" key={index}>{warning}</p>)}</div><div className="mic-test"><div><span className="mic-test-title">Microphone test</span><span className="mic-test-status">{capture.state === 'running' ? 'MICROPHONE ACTIVE · Listening' : capture.state.toUpperCase()}</span></div><div className="mic-test-actions"><button onClick={() => testMicrophone('start')} disabled={capture.state === 'running' || capture.state === 'starting'}>Test Microphone</button><button onClick={stopMicrophoneTest} disabled={!['running', 'paused', 'error'].includes(capture.state)}>Stop Test</button></div><div className="level-line"><span>Input level</span><div className="level-track"><div className="level-fill" style={{ width: (capture.level * 100) + '%' }} /></div><span>{Math.round(capture.level * 100)}%</span></div>{capture.error && <p className="device-warning">{capture.error}</p>}</div><MeetingControls status={status} onAction={action} onExport={exportFile} /><div className="feed-head"><span>Live transcript</span><span className="feed-note">ORIGINAL + TRANSLATION</span></div><TranscriptFeed items={items} /></div></main>;
}
