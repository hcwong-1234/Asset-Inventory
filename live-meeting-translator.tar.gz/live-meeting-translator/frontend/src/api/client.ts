const API=import.meta.env.VITE_API_BASE_URL||'http://127.0.0.1:8000';
async function parseResponse(response:Response){if(!response.ok){const body=await response.text();throw new Error('HTTP '+response.status+': '+(body||response.statusText))}return response.json()}
export async function createMeeting(title:string){return fetch(API+'/api/meetings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title})}).then(parseResponse)}
export async function meetingAction(id:string, action:string){return fetch(API+'/api/meetings/'+id+'/'+action,{method:'POST'}).then(parseResponse)}
export async function listDevices(){return fetch(API+'/api/devices').then(parseResponse)}
export async function microphoneTestAction(action:string,deviceId?:string){return fetch(API+'/api/audio/microphone/test/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:action==='start'?JSON.stringify({device_id:deviceId}):undefined}).then(parseResponse)}
export const microphoneTestWsUrl=()=>API.replace(/^http/,'ws')+'/api/audio/microphone/test/ws';
export const wsUrl=(id:string)=>API.replace(/^http/,'ws')+'/ws/meetings/'+id;
export const exportUrl=(id:string,format:string)=>API+'/api/meetings/'+id+'/export/'+format;
